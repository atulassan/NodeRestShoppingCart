var express = require('express'),
    app = express(),
    router = express.Router(),
    mysql = require('mysql'),
    bodyParser = require('body-parser'),
    morgan = require("morgan"),
    compression =  require('compression'),
    myConnection  = require('express-myconnection');

/**
 * Store database credentials in a separate config.js file
 * Load the file/module and its values
 */ 
var config = require('./config');

var dbOptions = {
	host:	  config.database.host,
	user: 	  config.database.user,
	password: config.database.password,
	port: 	  config.database.port, 
	database: config.database.db
}

/**
 * 3 strategies can be used
 * single: Creates single database connection which is never closed.
 * pool: Creates pool of connections. Connection is auto release when response ends.
 * request: Creates new connection per new request. Connection is auto close when response ends.
 */ 
app.use(myConnection(mysql, dbOptions, 'pool'));

// port number
var port = process.env.PORT || config.server.port;

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(bodyParser.urlencoded({ extended: true }));

// Parse JSON bodies (as sent by API clients)
app.use(bodyParser.json());

app.get('/', function (req, res) {
    res.setHeader('Content-Type', 'application/json');
    res.json({ ktm: "bike" });
});

//route Model
var categories = require('./models/categories');

//Middlewares
app.use(categories); //Categories Route Model Connect Middleware
app.use(morgan('dev')); //develop morgan
app.use(compression()); // Compress all Responses

// Assigning Port
app.listen(port, function () {
    console.log('Server listening on port ' + port + '...');
});